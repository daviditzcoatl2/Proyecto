//
//  Producto.swift
//  PF
//
//  Created by MacBook on 05/06/18.
//  Copyright © 2018 MacBook. All rights reserved.
//

import Foundation
struct Product {
    var nombre: String
    //var foto: String
    var precio: Double
    var cantidad: Int  // Cantidad en inventario
    var existencia: Bool //Si existe o no el producto
    var vendidos: Int //No. de productos vendidos
}

var productos = [Product]()

