//
//  Cell.swift
//  PF
//
//  Created by MacBook on 23/05/18.
//  Copyright © 2018 MacBook. All rights reserved.
//

import UIKit

class Cell: UITableViewCell {

    @IBOutlet weak var imagen: UIImageView!
    
    
    @IBOutlet weak var nombre: UILabel!
}
