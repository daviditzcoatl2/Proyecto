//
//  ViewController.swift
//  ProyectoFinal
//
//  Created by MacBook on 14/05/18.
//  Copyright © 2018 MacBook. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let formContainerView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.white
        view.translatesAutoresizingMaskIntoConstraints = false
        view.layer.cornerRadius = 5
        view.layer.masksToBounds = true
        return view
    }()
    
    let emailTextField: UITextField = {
        let tf = UITextField()
        tf.placeholder = "Correo electrónico"
        tf.translatesAutoresizingMaskIntoConstraints = false
        
        return tf
    }()
    
    let emailLabel: UILabel = {
        let correo = UILabel()
        correo.text = "Inserte correo"
        correo.textColor = UIColor.blue
        correo.translatesAutoresizingMaskIntoConstraints = false
        return correo
    }()
    
    let passwordText: UITextField = {
        let pt = UITextField()
        pt.placeholder = "Contraseña"
        pt.translatesAutoresizingMaskIntoConstraints = false
        return pt
    }()
    
    let passwordLabel: UILabel = {
        let passlabel = UILabel()
        passlabel.text = "Inserte contraseña"
        passlabel.textColor = UIColor.blue
        passlabel.translatesAutoresizingMaskIntoConstraints = false
        return passlabel
    }()
    
    let registerButton: UIButton = {
        let button = UIButton(type: .system)
        button.backgroundColor = UIColor(red: 0/255, green: 175/255, blue: 38/255, alpha: 1.0)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(UIColor.black, for: .normal )
        button.setTitle("Registro", for: .normal)
        
        // parte 2, hacemos grande la letra del boton
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 15)
        
        // parte 2 cuando es UX
        button.layer.cornerRadius = 5
        button.layer.masksToBounds = true
        
        return button
    }()
    
    let inicioSesion: UIButton = {
        let button = UIButton(type: .system)
        button.backgroundColor = UIColor(red: 0/255, green: 175/255, blue: 38/255, alpha: 1.0)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(UIColor.black, for: .normal )
        button.setTitle("Iniciar Sesión", for: .normal)
        
        // parte 2, hacemos grande la letra del boton
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 15)
        
        // parte 2 cuando es UX
        button.layer.cornerRadius = 5
        button.layer.masksToBounds = true
        
        return button
    }()
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        
        view.addSubview(formContainerView)
        view.addSubview(emailLabel)
        view.addSubview(emailTextField)
        view.addSubview(passwordText)
        view.addSubview(passwordLabel)
        view.addSubview(registerButton)
        view.addSubview(inicioSesion)
        
        
        emailTextField.leftAnchor.constraint(equalTo: view.centerXAnchor, constant: -75).isActive = true
        emailTextField.topAnchor.constraint(equalTo: view.centerYAnchor, constant: -100).isActive = true
        emailTextField.heightAnchor.constraint(equalToConstant: 60).isActive = true
        
        passwordText.leftAnchor.constraint(equalTo: view.centerXAnchor , constant: -75).isActive = true
        passwordText.topAnchor.constraint(equalTo: emailTextField.bottomAnchor).isActive = true
        passwordText.heightAnchor.constraint(equalToConstant: 60).isActive = true
        
        emailLabel.leftAnchor.constraint(equalTo: view.centerXAnchor, constant: -75).isActive = true
        emailLabel.topAnchor.constraint(equalTo: view.centerYAnchor, constant: -110).isActive = true
        
        passwordLabel.leftAnchor.constraint(equalTo: view.centerXAnchor, constant: -75).isActive = true
        passwordLabel.topAnchor.constraint(equalTo: passwordText.bottomAnchor, constant: -65).isActive = true
        
        registerButton.leftAnchor.constraint(equalTo: view.centerXAnchor, constant: -75).isActive = true
        registerButton.topAnchor.constraint(equalTo: passwordText.bottomAnchor, constant: 50).isActive = true
        
        inicioSesion.leftAnchor.constraint(equalTo: view.centerXAnchor, constant: -75).isActive = true
        inicioSesion.topAnchor.constraint(equalTo: passwordText.bottomAnchor, constant: 10).isActive = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

